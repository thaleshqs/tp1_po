# -*- coding: utf-8 -*-
import numpy as np
import math
import copy

#funcao do simplex
def getPivot(tableau, n, base):
  for i in range(len(tableau[0])):
    if abs(tableau[0, i]) < 1.e-7:
      tableau[0, i] = 0
  i = len(tableau[0]) - 2
  while i >= n and tableau[0, i] >= 0:
    i -= 1

  if i < n:
    return (-1,-1)

  pivotCol = i
  pivotRow = -1

  currMin = math.inf
  for i in range(len(tableau[:, 0]) - 1):    
    if tableau[i+1, len(tableau[0]) - 1] < 0:
      continue


    if abs(tableau[i+1, pivotCol]) <= 1.e-7:
      tableau[i+1, pivotCol] = 0
    
    if tableau[i+1, pivotCol] <= 0:
      continue

    ratio = tableau[i+1, len(tableau[0]) - 1] / tableau[i+1, pivotCol]
    if  ratio < currMin:
      pivotRow = i+1
      currMin = ratio 
  if pivotRow == -1:
    return (pivotRow, pivotCol)
  else:
    base[0, pivotRow - 1] = pivotCol - n
    return (pivotRow, pivotCol)

#funcao para pivoteamento
def pivot(pivotRow, pivotCol, tableau):
  if abs(tableau[pivotRow, pivotCol]) >=  1.e-7:
    A = tableau.copy()
    A[pivotRow] = np.array(tableau[pivotRow]) / tableau[pivotRow, pivotCol]
    for i, j in enumerate(tableau):
      if i != pivotRow:
        aux = np.array(A[pivotRow]) * tableau[i][pivotCol]
        A[i] = np.array(tableau[i]) - aux
    return A

#entrada
line1 = input()

#n restrições
#m variáveis
n, m = line1.split()
n, m = int(n), int(m)
cost = np.zeros((1, m))
line2 = input()
line2 = line2.split()

#vetor de custos
for i in range(m):
  cost[0, i] = float(line2[i])  

#matrizes
A = np.zeros((n,m))
b = np.zeros((n,1))
for i in range(n):
  line = input()
  line = [float(x) for x in line.split()]
  for j in range(m+1):
    if j == m:
      b[i, 0] = line[j]
    else:
      A[i, j] = line[j]

#construcao do tableau
tableau = np.zeros((n, m)) 

id = np.eye(n)
tableau = np.hstack((A, id))
tableau = np.hstack((id, tableau))

z = np.zeros((1,n)) 
aux = np.hstack((z, -cost))

aux = np.hstack((aux, z))
tableau = np.vstack((aux, tableau))
z = np.vstack(([[0]], b))
tableau = np.hstack((tableau, z))

for i in range(n):
  if b[i,0] < 0:
    tableau[i+1] *= -1


sol = np.zeros((1, m + n + n))
newCost = np.zeros((1, n + len(tableau[0])))
i = len(newCost[0]) - 2
while i >= len(newCost[0]) - n - 1 :
  newCost[0, i] = 1
  i -= 1

base = np.zeros((1,n), dtype='int')
for i in range(n):
  sol[0,m+n+i] = tableau[i+1, len(tableau[0]) - 1]
  base[0,i] = m + n + i 

aux = np.eye(n)
aux = np.hstack((tableau[1:, 0 : len(tableau[0]) - 1], aux))
newTableau = np.vstack((newCost[:,0 : len(newCost[0]) - 1], aux))

y = tableau[:, len(tableau[0]) - 1].reshape(-1,1)

newTableau = np.hstack((newTableau, y))


A = newTableau.copy()

j = len(newTableau[0]) - n - 1
i = 1
while  j < len(newTableau[0]) - 1:
  A = pivot(i,j, A)
  j += 1
  i += 1

#1a fase do simplex
while True:
  a, b = getPivot(A, n, base)
  if b == -1:
    break
  else:
    A = pivot(a, b, A)

if A[0, len(A[0]) - 1] < 0:
  print("inviavel")
  
  for i in range(n):
    print("{:0.7f}".format(A[0,i]), end = ' ')
else:
  aux = A[:,len(A[0]) - 1].reshape(-1,1)
  A = np.hstack((A[:, 0 : len(A[0]) - 1 - n], aux))
  A[0] = tableau[0]
  j = 1
  for i in base[0]:
    if i + n <= len(A[0]-1):
        A = pivot(j,i + n, A)
    j += 1


  #2a fase do simplex
  while True:
    a, b = getPivot(A, n, base)
    if b == -1:
      sol = np.zeros((1, m))
      for i in range(n):
        if base[0, i] < m:
          ind = 1
          while np.round(A[ind,base[0,i] + n], 4) != 1:
            ind += 1
          sol[0, base[0,i]] = A[ind, len(A[0]) - 1]
      print("otima")
      print("{:0.7f}".format(A[0, len(A[0]) - 1]))
      for i in range(m):
        print("{:0.7f}".format(sol[0, i]), end = ' ')
      

      print("\n", end = '')
      for i in range(n):
        print("{:0.7f}".format(A[0,i]), end = ' ')
      break
    elif a == -1:
      sol = np.zeros((1, m))
      certificate = np.zeros((1, m+n))
      certificate[0, b - n] = 1
      for i in range(0, n):
        certificate[0, base[0, i]] = -A[i+1, b]

      for i in range(n, len(A[0]) - 1 - n):
        if np.round(A[0,i], 4) == 0:
          one, zero = 0, 0
          ind = -1
          for j in range(1, n+1):
            if np.round(A[j,i], 4) == 1:
              one += 1
              ind = j
            elif np.round(A[j,i],4) == 0:
              zero += 1
          if one == 1 and zero == n - 1:
            sol[0, i - n] = A[ind, len(A[0]) - 1]
      print("ilimitada")
      for i in range(m):
        print("{:0.7f}".format(sol[0, i]), end = ' ')
      print("\n", end ='')
      for i in range(m):
        print("{:0.7f}".format(certificate[0, i]), end = ' ')
      break
    else:
      A = pivot(a, b, A)